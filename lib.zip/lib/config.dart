import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// تطوير محلي:
/// - **محاكي أندرويد (موصى به على Windows):** `http://127.0.0.1:3000`
///   بعد تنفيذ: `adb reverse tcp:3000 tcp:3000`
/// - بدون reverse: `--dart-define=SERVER_HOST=10.0.2.2` + الباك اند على `HOST=0.0.0.0`
///   وفتح المنفذ 3000 في جدار حماية Windows.
/// - **ويب / سطح المكتب:** `localhost`.
class AppConfig {
  AppConfig._();

  static const String _port = String.fromEnvironment(
    'SERVER_PORT',
    defaultValue: '3000',
  );
  static const String _overrideHost = String.fromEnvironment(
    'SERVER_HOST',
    defaultValue: '',
  );

  static String get fallbackApiBase {
    if (_overrideHost.isNotEmpty) {
      return 'http://$_overrideHost:$_port';
    }
    if (kIsWeb) {
      return 'http://localhost:$_port';
    }
    if (defaultTargetPlatform == TargetPlatform.android) {
      return 'http://127.0.0.1:$_port';
    }
    return 'http://localhost:$_port';
  }
}
